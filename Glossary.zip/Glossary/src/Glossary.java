import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * The output of the Glossary shall be a group of HTML files. There shall be a
 * top-level index which merely lists each term in the glossary, and separate
 * pages for each of the terms with their definitions. Clicking on a term in the
 * index shall take you to the page for that term and its associated definition.
 * Moreover, clicking on any term in the glossary that happens to appear in a
 * definition shall take you to the page for that term and its associated
 * definition.
 *
 * @author Rita Brokhman
 *
 */
public final class Glossary {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Glossary() {
    }

    /**
     * Read lines from given file and store them in a map with the term as a key
     * and the definition as the value
     *
     * @param in
     *            reading input from file
     * @param Pairs
     *            the map that contains term and definition pairs
     * @update Pairs
     */
    public static void processInput(SimpleReader in,
            Map<String, String> Pairs) {
        String term = "";
        String definition = "";

        /**
         * txt file is formatted so that each term is its own line and each
         * definition is its own sentence/line with an empty line between every
         * other definition and term
         */

        while (!in.atEOS()) {
            String line = in.nextLine();
            if (isTerm(line)) {
                term = line;
            } else if (isDefinition(line)) {
                definition += line;
            } else {
                Pairs.add(term, definition);
                term = "";
                definition = "";
            }
        }
        if (term.length() > 0 && definition.length() > 0) {
            Pairs.add(term, definition);
        }
    }

    /**
     * Check if {@code str} is a single word.
     *
     * @param str
     *            individual string from input file
     * @return if {@code str} is a single "word"
     *
     */
    public static boolean isTerm(String str) {
        // Every term shall consist of a single "word" (i.e., a term contains no whitespace characters)
        boolean answer = true;
        if (str.length() < 1 || str.contains(" ")) {
            answer = false;
        }
        return answer;
    }

    /**
     * Check if {@code str} is a definition (sentence).
     *
     * @param str
     *            individual string from input file
     * @return if {@code str is a definition}
     */
    public static boolean isDefinition(String str) {
        boolean answer = false;
        if (str.length() < 1) {
            answer = false;
        } else {
            for (int i = 0; i < str.length(); i++) {
                if (str.charAt(i) == ' ') {
                    answer = true;
                }
            }
        }
        return answer;
    }

    private static class alphabetize implements Comparator<String> {

        /**
         * Alphabetizes the terms in the Map (single "words").
         *
         * @param str1
         *            the first String
         * @param str2
         *            the second String
         * @return 1 if {@code str1} is larger than {@code str2} -1 if
         *         {@code str1} is larger than {@code str2} 0 if @code str1}
         *         equals to {@code str2}
         */
        @Override
        public int compare(String str1, String str2) {
            if (str1.compareTo(str2) < 0) {
                return -1;
            } else if (str1.compareTo(str2) > 0) {
                return 1;
            } else {
                return 0;
            }
        }
    }

    /**
     * Takes terms from Map and stores them into a sorted Queue with their
     * matching definitions.
     *
     * @param Pairs
     *            Map that stores all terms and definitions
     * @return Sorted Queue<String> of all terms
     */
    public static Queue<String> sortTerms(Map<String, String> Pairs) {
        Queue<String> termsInOrder = new Queue1L<String>();
        // Add terms from Map to Queue
        for (Map.Pair<String, String> term : Pairs) {
            termsInOrder.enqueue(term.key());
        }

        // Use Queue Sort Method
        Comparator<String> alphabetized = new alphabetize();
        termsInOrder.sort(alphabetized);
        return termsInOrder;
    }

    /**
     * Finds all terms (words to be hyperlinked) from a definition
     *
     * @param str
     *            the given definition
     * @param Pairs
     *            a Map<String, String> that stores all terms
     * @return a Set<String> that stores all terms inside a definition
     */
    public static Set<String> termsInDefinition(String str,
            Map<String, String> Pairs) {
        Set<String> termsInsideDef = new Set1L<String>();
        for (Map.Pair<String, String> termInside : Pairs) {
            // If term inside of a definition has not already been added to the Set, add it
            if (str.contains(termInside.key())
                    && !termsInsideDef.contains(termInside.key())) {
                termsInsideDef.add(termInside.key());
            }
        }
        return termsInsideDef;
    }

    /**
     * Prints hyperlinks for terms inside a given definition
     *
     * @param term
     *            a term inside a definition
     * @return a String with generated html code
     */
    public static String termWithHyperlink(String term) {
        return "<a href=\"" + term + ".html\">";
    }

    /**
     * Prints index.html, the top-level index containing all terms and
     * definitions
     *
     * @param hyperlinked
     *            all terms that need to be printed with hyperlink
     * @param output
     *            outputs file with definitions and terms and terms with
     *            hyperlinks
     */
    public static void printIndex(Queue<String> hyperlinked, String output) {
        // The top-level index shall be named index.html and the page for each
        // term shall be named term.html where term is the actual term.
        SimpleWriter file = new SimpleWriter1L(output + "/" + "index.html");
        file.print("<html>\n<head>\n<title>Glossary</title>\n</head>\n");
        file.print("<body>\n<h2>Glossary</h2>\n<hr />\n<h3>Index</h3>\n<ul>\n");
        for (String termToLink : hyperlinked) {
            file.println("<li><a href=\"" + termToLink + ".html\">" + termToLink
                    + "</a></li>");
        }
        file.print("</ul>\n</body>\n</html>\n");
        file.close();
    }

    /**
     * Prints all terms, each with term.html.
     *
     * @param Pairs
     *            a Map<String, String> that stores all terms with definitions
     * @param output
     *            where to generate files
     */
    public static void printTerms(Map<String, String> Pairs, String output) {
        Set<String> termsInDef = new Set1L<String>();

        for (Map.Pair<String, String> term : Pairs) {
            SimpleWriter out = new SimpleWriter1L(
                    output + "/" + term.key() + ".html");

            // Normal Terms
            out.print("<html>\n<head>\n<title>" + term.key()
                    + "</title>\n</head>\n");
            // In each term's page, that term shall appear in red boldface
            // italics just before its definition.
            out.print("<body>\n<h2><b><i><font color=\"red\">" + term.key()
                    + "</font></i></b></h2>\n");
            String definition = term.value();
            termsInDef = termsInDefinition(term.value(), Pairs);

            // Hyperlinked Terms
            for (String inDef : termsInDef) {
                // Break up definition to encompass hyperlinked word
                definition = definition.substring(0, definition.indexOf(inDef))
                        + termWithHyperlink(inDef) + inDef + "</a>"
                        + definition.substring(
                                definition.indexOf(inDef) + inDef.length());
            }

            out.print("<blockquote>" + definition + "</blockquote>");
            out.println("<hr />");
            // Must return to index from each definition
            out.println("<p>Return to <a href=\"index.html\">index</a>.</p>");
            out.print("</body>\n</html>");
            out.close();
        }
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        Map<String, String> Pairs = new Map1L<String, String>();

        out.print("Enter the txt file name:");
        String file = in.nextLine();
        out.print("Enter the folder name:");
        String folder = in.nextLine();

        SimpleReader processFile = new SimpleReader1L(file);
        processInput(processFile, Pairs);

        Queue<String> sortedTerms = new Queue1L<String>();
        sortedTerms = sortTerms(Pairs);
        printIndex(sortedTerms, folder);
        printTerms(Pairs, folder);

        in.close();
        out.close();
    }

}