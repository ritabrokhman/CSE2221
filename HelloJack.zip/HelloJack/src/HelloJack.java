import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Simple HelloWorld program.
 *
 * @author Rita Brokhman
 */
public final class HelloJack {

    /**
     * No-argument constructor--private to prevent instantiation.
     */
    private HelloJack() {
        // no code needed here
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        SimpleWriter out = new SimpleWriter1L();
        SimpleReader in = new SimpleReader1L();

        out.print("Please enter your name: ");
        String name = in.nextLine();

        out.println("Hello, " + name);

        out.close();
        in.close();
    }

}