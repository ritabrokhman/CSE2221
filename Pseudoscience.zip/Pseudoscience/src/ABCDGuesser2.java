import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

/**
 * Put a short phrase describing the program here.
 *
 * @author Rita Brokhman
 *
 */
public final class ABCDGuesser2 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private ABCDGuesser2() {
    }

    /**
     * * Repeatedly asks the user for a positive real number until the user
     * enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream *
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        out.print("Enter a positive real number: ");
        String input = in.nextLine();

        // while the input entered is not a double or negative
        while (!FormatChecker.canParseDouble(input)
                || Double.parseDouble(input) <= 0.0) {
            out.print("Enter a positive real number: ");
            input = in.nextLine();
        }

        double answer = Double.parseDouble(input);
        return answer;
    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in,
            SimpleWriter out) {
        out.print("Enter a positive real number that is not equal to 1.0: ");
        String input = in.nextLine();

        // while the input is not a double or equal to 1.0 or less than 0.0
        while (!FormatChecker.canParseDouble(input)
                || Double.parseDouble(input) == 1.0
                || Double.parseDouble(input) < 0.0) {
            out.print(
                    "Enter a positive real number that is not equal to 1.0: ");
            input = in.nextLine();
        }

        double answer = Double.parseDouble(input);
        return answer;
    }

    /**
     * Calculates the relative error between the user entered number and the de
     * Jager approximation.
     *
     * @param numerator
     *            the numerator in the relative error equation (actual -
     *            approximated)
     * @param denominator
     *            the denominator in the relative error equation (actual)
     * @return the relative error between the user entered number and the de
     *         Jager approximation.
     */
    private static double calcRelError(double numerator, double denominator) {
        double e = (numerator / denominator) * 100.0;
        return e;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        // ask the user what constant μ should be approximated
        out.println("**Please insert a constant to be approximated**");
        double mu = getPositiveDouble(in, out);

        // asks in turn for each of the four personal numbers w, x, y, and z
        out.println(
                "**Enter your first personal number (must be positive and not equal to 1)**");
        double w = getPositiveDoubleNotOne(in, out);
        out.println(
                "**Enter your second personal number (must be positive and not equal to 1)**");
        double x = getPositiveDoubleNotOne(in, out);
        out.println(
                "**Enter your third personal number (must be positive and not equal to 1)**");
        double y = getPositiveDoubleNotOne(in, out);
        out.println(
                "**Enter your fourth personal number (must be positive and not equal to 1)**");
        double z = getPositiveDoubleNotOne(in, out);

        int aCount = 0, bCount = 0, cCount = 0, dCount = 0;
        double a = 0, b = 0, c = 0, d = 0;

        // all possible values for a, b, c, and d (17 values)
        final double[] exponents = { -5, -4, -3, -2, -1, -1.0 / 2, -1.0 / 3,
                -1.0 / 4, 0, 1.0 / 4, 1.0 / 3, 1.0 / 2, 1, 2, 3, 4, 5 };

        // actual value - approximated value
        // numerator for relative error formula
        double numerator = ((Math.pow(w, exponents[0]))
                * (Math.pow(x, exponents[0])) * (Math.pow(y, exponents[0]))
                * (Math.pow(z, exponents[0]))) - mu;

        // cycling through all of the possible exponent values
        // approximating the value with de Jager's formula
        for (dCount = 0; dCount < exponents.length; dCount++) {
            for (cCount = 0; cCount < exponents.length; cCount++) {
                for (bCount = 0; bCount < exponents.length; bCount++) {
                    for (aCount = 0; aCount < exponents.length; aCount++) {
                        double approximate = ((Math.pow(w, exponents[aCount]))
                                * (Math.pow(x, exponents[bCount]))
                                * (Math.pow(y, exponents[cCount]))
                                * (Math.pow(z, exponents[dCount]))) - mu;
                        // the approximate cannot be smaller than the original mu entered
                        // size of the possible exponents decreased for optimal solution
                        if (Math.abs(approximate) < Math.abs(numerator)) {
                            numerator = approximate;
                            a = exponents[aCount];
                            b = exponents[bCount];
                            c = exponents[cCount];
                            d = exponents[dCount];
                        }
                    }
                    aCount = 0;
                }
                bCount = 0;
            }
            cCount = 0;
        }

        // calculating the de Jager formula and relative error
        double answer = mu + numerator;
        double relativeError = calcRelError(numerator, mu);

        // printing the answer, relative error, and exponents
        out.print("The answer is: ");
        out.print(answer, 0, false);
        out.println();

        out.print("The relative error is: ");
        out.print(relativeError, 2, false);
        out.print("%");
        out.println();

        out.println("a: " + a + " b: " + b + " c: " + c + " d: " + d);

        // close input and output streams
        in.close();
        out.close();
    }

}