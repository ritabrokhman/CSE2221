import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Rita Brokhman
 *
 */
public final class Newton3 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private Newton3() {
    }

    /**
     * Computes estimate of square root of x to within relative error 0.01%.
     *
     * @param input
     *            positive number to compute square root of
     * 
     * @param e
     *            relative error
     *
     * @return estimate of square root
     */
    private static double sqrt(double x, double e) {
        // a good initial guess for x^1/2 is simply r = x
        double r = x;

        // continue updating r until |r^2 – x |/x < ε^2
        while (Math.abs(r * r - x) / x > e * e) {
            // if you repeatedly replace your current guess r by
            //(r + x/r)/2, then your sequence of guesses should
            // converge to x^1/2
            r = (r + (x / r)) / 2;
        }
        return r;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        double input = 0.0;
        double relativeError = 0.0001;
        String stopCondition = "y";

        do {
            // asks user which number they would like to Newton square root
            out.print("Please enter a positive double to square root: ");
            input = in.nextDouble();
            out.print("Please enter a relative error: ");
            relativeError = in.nextDouble();

            // make sure Newton square root also works for entries of 0
            if (input == 0.0) {
                out.print("Division by zero (0) is undefined.");
            } else {
                // call the sqrt(double x) method to find the Newton square root
                out.print("The Newton square root of " + input
                        + " with relative error " + relativeError + " is: ");
                out.print(sqrt(input, relativeError));
            }

            // repeatedly ask to calculate another Newton square root
            out.println();
            out.print(
                    "Would you like to calculate another square root? (y/n): ");
            stopCondition = in.nextLine();
            out.println();
        } while (stopCondition.equals("y"));

        // Close input and output streams
        in.close();
        out.close();
    }

}