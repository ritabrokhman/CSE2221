import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class StringReassemblyTest {

    // routine test combination - overlap
    @Test
    public void testCombination() {
        String str1 = "starrynight";
        String str2 = "nightandday";
        int overlap = 5;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("starrynightandday", result);
    }

    // routine test combination - no overlap
    @Test
    public void testCombination1() {
        String str1 = "starrynight";
        String str2 = "andday";
        int overlap = 0;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("starrynightandday", result);
    }

    // routine test addToSetAvoidingSubstrings - overlap
    @Test
    public void testaddToSetAvoidingSubstrings() {
        Set<String> strset = new Set1L<>();
        strset.add("The sun");
        strset.add("The moon");
        strset.add("Stars");

        Set<String> strset2 = new Set1L<>();
        strset2.add("The sun");
        strset2.add("The moon");
        strset2.add("Stars");
        String str = "Stars";
        StringReassembly.addToSetAvoidingSubstrings(strset, str);
        assertEquals(strset, strset2);
    }

    // routine test addToSetAvoidingSubstrings - no overlap
    @Test
    public void testaddToSetAvoidingSubstrings1() {
        Set<String> strset = new Set1L<>();
        strset.add("The sun");
        strset.add("The moon");
        strset.add("Stars");

        Set<String> strset2 = new Set1L<>();
        strset2.add("The sun");
        strset2.add("The moon");
        strset2.add("Stars");
        strset2.add("Sky");
        String str = "Sky";
        StringReassembly.addToSetAvoidingSubstrings(strset, str);
        assertEquals(strset, strset2);
    }

    @Test
    //routine test printWithLineSeparators - with separators
    public void printWithLineSeparatorsTest() {
        SimpleWriter out = new SimpleWriter1L();
        out.println("Test 1: ");
        String test = "I~love~stars~and~skies";

        StringReassembly.printWithLineSeparators(test, out);

        out.close();
    }

    @Test
    //routine test printWithLineSeparators - without separators
    public void printWithLineSeparatorsTest1() {
        SimpleWriter out = new SimpleWriter1L();
        out.println();
        out.println();
        out.println("Test 2: ");
        String test = "I love stars and skies";

        StringReassembly.printWithLineSeparators(test, out);

        out.close();
    }

}
