import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * Controller class.
 *
 * @author Rita Brokhman
 */
public final class NNCalcController1 implements NNCalcController {

    /**
     * Model object.
     */
    private final NNCalcModel model;

    /**
     * View object.
     */
    private final NNCalcView view;

    /**
     * Useful constants.
     */
    private static final NaturalNumber TWO = new NaturalNumber2(2),
            INT_LIMIT = new NaturalNumber2(Integer.MAX_VALUE);

    /**
     * Updates this.view to display this.model, and to allow only operations
     * that are legal given this.model.
     *
     * @param model
     *            the model
     * @param view
     *            the view
     * @ensures [view has been updated to be consistent with model]
     */
    private static void updateViewToMatchModel(NNCalcModel model,
            NNCalcView view) {

        // Establishes the top and bottom as output and input,
        // and makes the values NNs
        NaturalNumber input = model.bottom();
        NaturalNumber output = model.top();

        // Update displays
        view.updateBottomDisplay(input);
        view.updateTopDisplay(output);

        // Reference the variable from the method
        // definition called "allowed"
        boolean allowed = true;

        // Ensures that subtraction can occur:
        // If the top number is larger than the bottom,
        // subtraction is allowed and no negative answers
        // will be produced
        if (input.compareTo(model.top()) < 0) {
            allowed = true;
            view.updateSubtractAllowed(allowed);
        } else {
            allowed = false;
            view.updateSubtractAllowed(allowed);
        }

        // Ensures that division can occur:
        // If the top number is larger than the bottom,
        // division is allowed
        if (input.compareTo(new NaturalNumber2()) > 0) {
            allowed = true;
            view.updateDivideAllowed(allowed);
        } else {
            allowed = false;
            view.updateDivideAllowed(allowed);
        }

        // Ensures that power can occur:
        // If the input does not exceed the max limit,
        // power is allowed
        if (input.compareTo(INT_LIMIT) <= 0) {
            allowed = true;
            view.updatePowerAllowed(allowed);
        } else {
            allowed = false;
            view.updatePowerAllowed(allowed);
        }

        // Ensures that root can occur:
        // If the input is greater than or equal to 2 (sqrt of 1 is 1),
        // and is within the max limit, root is allowed
        if (input.compareTo(TWO) >= 0 && input.compareTo(INT_LIMIT) <= 0) {
            allowed = true;
            view.updateRootAllowed(allowed);
        } else {
            allowed = false;
            view.updateRootAllowed(allowed);
        }
    }

    /**
     * Constructor.
     *
     * @param model
     *            model to connect to
     * @param view
     *            view to connect to
     */
    public NNCalcController1(NNCalcModel model, NNCalcView view) {
        this.model = model;
        this.view = view;
        updateViewToMatchModel(model, view);
    }

    @Override
    public void processClearEvent() {
        /*
         * Get alias to bottom from model
         */
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        bottom.clear();
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSwapEvent() {
        /*
         * Get aliases to top and bottom from model
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        NaturalNumber temp = top.newInstance();
        temp.transferFrom(top);
        top.transferFrom(bottom);
        bottom.transferFrom(temp);
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processEnterEvent() {

        // Stores the numbers in the top and bottom as NNs
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Move the bottom value to the top after entered
        top.copyFrom(bottom);

        // Update view each time
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processAddEvent() {

        // Stores the numbers in the top and bottom as NNs
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Adds the top and bottom NNs and clears the bottom to enter another input
        bottom.add(top);
        top.clear();

        // Update view each time
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSubtractEvent() {

        // Stores the numbers in the top and bottom as NNs
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Subtracts the bottom from the top NN,
        // moves the answer aka bottom to the top,
        // and clears the bottom to enter another input
        top.subtract(bottom);
        bottom.transferFrom(top);

        // Update view each time
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processMultiplyEvent() {

        // Stores the numbers in the top and bottom as NNs
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Multiplies the top by the bottom NN and clears the bottom to enter another input
        bottom.multiply(top);
        top.clear();

        // Update view each time
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processDivideEvent() {

        // Stores the numbers in the top and bottom as NNs
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Divides the top by the bottom NN,
        // Store the division result in the bottom,
        // and transfer the result to the top
        NaturalNumber remainder = top.divide(bottom);
        bottom.transferFrom(top);
        top.transferFrom(remainder);

        // Update view each time
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processPowerEvent() {

        // Stores the numbers in the top and bottom as NNs
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Raises the top NN to the p-th power,
        // so the power is entered as an int because of the
        // power method's requirements.
        // Transfer the result to the top
        int p = bottom.toInt();
        top.power(p);
        bottom.transferFrom(top);

        // Update view each time
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processRootEvent() {

        // Stores the numbers in the top and bottom as NNs
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        // Takes the r-th root of the top NN,
        // so the root is entered as an int because of the
        // root method's requirements.
        // Transfer the result to the top
        int r = bottom.toInt();
        top.root(r);
        bottom.transferFrom(top);

        // Update view each time
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processAddNewDigitEvent(int digit) {

        /*
         * Get aliases to bottom from model
         */
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        bottom.multiplyBy10(digit);
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);

    }

}
